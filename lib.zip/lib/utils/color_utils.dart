import 'package:flutter/material.dart';

class ColorsUtil {
  static const background = Color(0xff1B1A1C);
  static const headline = Color(0xff33272a);
  static const paragraph = Color(0xffffffff);
  static const btnText = Color(0xff000000);
  static const btn = Color(0xff1ED760);
}
