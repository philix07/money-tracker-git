import 'package:flutter/material.dart';

class DatabaseTest extends StatefulWidget {
  const DatabaseTest({super.key});

  @override
  State<DatabaseTest> createState() => _DatabaseTestState();
}

class _DatabaseTestState extends State<DatabaseTest> {
  @override
  Widget build(BuildContext context) {
    return Container();
  }
}